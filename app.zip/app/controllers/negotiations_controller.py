from PySide6.QtCore import QObject, Qt
from PySide6.QtGui import QStandardItemModel, QStandardItem, QColor
from sqlalchemy.orm import joinedload

from database import get_db_session
from app.models.purchase_models import LigneCommande, Commande
from app.models.shared_models import Article, Fournisseur, PieceExtension # Assurez-vous d'importer Fournisseur

class NegotiationsController(QObject):
    def __init__(self, view):
        super().__init__()
        print("DEBUG Controller __init__: START")
        self.view = view
        self.model = QStandardItemModel()
        
        if hasattr(self.view, 'table_view') and self.view.table_view is not None:
            self.view.table_view.setModel(self.model)
            print("DEBUG Controller __init__: table_view model set.")
        else:
            print("ERROR Controller __init__: self.view.table_view NOT FOUND or is None!")

        self.current_sort_mode = "commande" 
        print(f"DEBUG Controller __init__: Initial sort mode: {self.current_sort_mode}")
        
        # Tentative de connexion directe et test immédiat
        self.view.toggle_sort_button.clicked.connect(self.toggle_sort_and_reload)            
        self.load_negotiation_data()
        print("DEBUG Controller __init__: END")

    def toggle_sort_and_reload(self):
        print("--- TOGGLE_SORT_AND_RELOAD CALLED ---") # Message clé
        print(f"DEBUG TOGGLE: Before toggle, current mode: {self.current_sort_mode}") # DEBUG
        if self.current_sort_mode == "commande":
            self.current_sort_mode = "piece"
            self.view.toggle_sort_button.setText(self.view.tr("Sort by Purchase Order"))
            print("DEBUG TOGGLE: Mode changed to 'piece'. Button text should be 'Sort by PO'.") # DEBUG
        else: # current_sort_mode était 'piece'
            self.current_sort_mode = "commande"
            self.view.toggle_sort_button.setText(self.view.tr("Sort by Item Reference"))
            print("DEBUG TOGGLE: Mode changed to 'commande'. Button text should be 'Sort by Item Ref'.") # DEBUG
        
        print(f"DEBUG TOGGLE: After toggle, new mode: {self.current_sort_mode}") # DEBUG
        self.load_negotiation_data()

    def load_negotiation_data(self):
        print(f"Loading negotiation data (Sort mode: {self.current_sort_mode})...")
        self.model.clear()
        
        # Les headers restent les mêmes car le tableau a toujours le même nombre de colonnes de base
        headers = [
            "PO Number", "Order Date", "Supplier", 
            "Item Ref.", "Item Name", "Machine",
            "Qty", "Reference Price (Unit)", "Negotiated Price (Unit)",
            "Unit Saving", "Total Saving for Line"
        ]
        self.model.setHorizontalHeaderLabels([self.view.tr(h) for h in headers])
        
        total_savings_all_lines = 0.0
        session = next(get_db_session())
        try:
            # La requête de base reste la même, triée pour le groupement
            query = session.query(LigneCommande).join(LigneCommande.commande).options(
                joinedload(LigneCommande.piece).joinedload(Article.extension_info).joinedload(PieceExtension.machine),
                joinedload(LigneCommande.commande).joinedload(Commande.fournisseur)
            ).filter(
                Commande.statut.notin_(['Brouillon', 'Annulee'])
            )

            if self.current_sort_mode == "piece":
                print("DEBUG LOAD: Applying sort by Item Reference (piece) for GROUPING LOGIC")
                # Tri principal pour le groupement par pièce
                query = query.join(LigneCommande.piece).order_by(Article.reference, Commande.date_commande.desc())
                
                finalized_lines = query.all()
                print(f"DEBUG LOAD (Piece Mode): Query executed. Found {len(finalized_lines)} lines.")

                current_piece_id = None
                piece_group_start_row = -1
                rows_in_current_group = 0

                for ligne in finalized_lines:
                    if not ligne.piece: continue

                    # Si c'est une nouvelle pièce, on crée la "ligne d'en-tête" de la pièce
                    if ligne.piece.id_piece != current_piece_id:
                        # Avant de commencer un nouveau groupe, finaliser le rowspan du groupe précédent
                        if piece_group_start_row != -1 and rows_in_current_group > 0:
                            # Les 3 premières colonnes (réf, nom, machine) de la ligne d'en-tête s'étendent
                            self.view.table_view.setSpan(piece_group_start_row, 0, rows_in_current_group, 1) # Réf Pièce
                            self.view.table_view.setSpan(piece_group_start_row, 1, rows_in_current_group, 1) # Nom Pièce
                            self.view.table_view.setSpan(piece_group_start_row, 2, rows_in_current_group, 1) # Machine
                        
                        current_piece_id = ligne.piece.id_piece
                        piece_group_start_row = self.model.rowCount() # La nouvelle ligne sera à cet index
                        rows_in_current_group = 0
                        
                        machine_name = "N/A"
                        if ligne.piece.extension_info and ligne.piece.extension_info.machine:
                            machine_name = ligne.piece.extension_info.machine.nom

                        header_row_items = [
                            QStandardItem(ligne.piece.reference),  # Réf. Pièce
                            QStandardItem(ligne.piece.designation), # Nom Pièce
                            QStandardItem(machine_name),           # Machine
                            QStandardItem(""), # PO Number (vide pour la ligne d'en-tête pièce)
                            QStandardItem(""), # Order Date
                            QStandardItem(""), # Supplier
                            QStandardItem(""), # Qty
                            QStandardItem(""), # Ref Price
                            QStandardItem(""), # Neg Price
                            QStandardItem(""), # Unit Saving
                            QStandardItem("")  # Total Saving
                        ]
                        # Mettre en forme la ligne d'en-tête de la pièce
                        for item in header_row_items[:3]: # Les 3 premières colonnes
                            font = item.font()
                            font.setBold(True)
                            item.setFont(font)
                            item.setBackground(QColor("#E0E0E0")) # Gris clair
                        self.model.appendRow(header_row_items)
                        rows_in_current_group += 1


                    # Maintenant, la ligne de détail de la commande pour cette pièce
                    reference_price_unit = float(ligne.piece.prix_achat_ht) if ligne.piece.prix_achat_ht is not None else 0.0
                    negotiated_price_unit = float(ligne.prix_unitaire_ht)
                    quantity = int(ligne.quantite_commandee)
                    unit_saving = reference_price_unit - negotiated_price_unit
                    line_total_saving = unit_saving * quantity
                    total_savings_all_lines += line_total_saving

                    detail_row_items = [
                        QStandardItem(""), # Réf. Pièce (vide, sera couvert par rowspan)
                        QStandardItem(""), # Nom Pièce (vide)
                        QStandardItem(""), # Machine (vide)
                        QStandardItem(ligne.commande.numero_commande or str(ligne.commande.id_commande)),
                        QStandardItem(str(ligne.commande.date_commande)),
                        QStandardItem(ligne.commande.fournisseur.nom if ligne.commande.fournisseur else "N/A"),
                        QStandardItem(str(quantity)),
                        QStandardItem(f"{reference_price_unit:.2f}"),
                        QStandardItem(f"{negotiated_price_unit:.2f}"),
                        QStandardItem(f"{unit_saving:.2f}"),
                        QStandardItem(f"{line_total_saving:.2f}")
                    ]
                    # Coloration
                    if unit_saving > 0:
                        detail_row_items[9].setForeground(QColor("green"))
                        detail_row_items[10].setForeground(QColor("green"))
                    elif unit_saving < 0:
                        detail_row_items[9].setForeground(QColor("red"))
                        detail_row_items[10].setForeground(QColor("red"))
                    
                    self.model.appendRow(detail_row_items)
                    rows_in_current_group += 1

                # Appliquer le rowspan pour le dernier groupe
                if piece_group_start_row != -1 and rows_in_current_group > 0:
                    self.view.table_view.setSpan(piece_group_start_row, 0, rows_in_current_group, 1)
                    self.view.table_view.setSpan(piece_group_start_row, 1, rows_in_current_group, 1)
                    self.view.table_view.setSpan(piece_group_start_row, 2, rows_in_current_group, 1)

            else: # Tri par 'commande' (logique existante)
                print("DEBUG LOAD: Applying sort by Purchase Order (commande)")
                query = query.order_by(Commande.date_commande.desc(), LigneCommande.id_ligne)
                finalized_lines = query.all()
                print(f"DEBUG LOAD (Commande Mode): Query executed. Found {len(finalized_lines)} lines.")
                for ligne in finalized_lines:
                    # ... (votre code existant pour peupler les lignes en mode commande)
                    # ... (copiez-le ici, en vous assurant que les colonnes correspondent aux headers)
                    if not ligne.piece: continue
                    machine_name = "N/A"
                    if ligne.piece.extension_info and ligne.piece.extension_info.machine:
                        machine_name = ligne.piece.extension_info.machine.nom
                    reference_price_unit = float(ligne.piece.prix_achat_ht) if ligne.piece.prix_achat_ht is not None else 0.0
                    negotiated_price_unit = float(ligne.prix_unitaire_ht)
                    quantity = int(ligne.quantite_commandee)
                    unit_saving = reference_price_unit - negotiated_price_unit
                    line_total_saving = unit_saving * quantity
                    total_savings_all_lines += line_total_saving
                    row = [
                        QStandardItem(ligne.commande.numero_commande or str(ligne.commande.id_commande)),
                        QStandardItem(str(ligne.commande.date_commande)),
                        QStandardItem(ligne.commande.fournisseur.nom if ligne.commande.fournisseur else "N/A"),
                        QStandardItem(ligne.piece.reference),
                        QStandardItem(ligne.piece.designation),
                        QStandardItem(machine_name),
                        QStandardItem(str(quantity)),
                        QStandardItem(f"{reference_price_unit:.2f}"),
                        QStandardItem(f"{negotiated_price_unit:.2f}"),
                        QStandardItem(f"{unit_saving:.2f}"),
                        QStandardItem(f"{line_total_saving:.2f}")
                    ]
                    if unit_saving > 0: row[9].setForeground(QColor("green")); row[10].setForeground(QColor("green"))
                    elif unit_saving < 0: row[9].setForeground(QColor("red")); row[10].setForeground(QColor("red"))
                    self.model.appendRow(row)

            print(f"Loaded {len(finalized_lines)} effective lines for negotiation report display.")
            self.view.total_savings_value_label.setText(f"{total_savings_all_lines:.2f} EUR")

        except Exception as e:
            print(f"Error loading negotiation data: {e}")
            import traceback
            traceback.print_exc()
            self.view.total_savings_value_label.setText(self.view.tr("Error"))
        finally:
            session.close()

        self.view.table_view.resizeColumnsToContents()
        # En mode 'piece', le tri par colonne n'a plus beaucoup de sens à cause du rowspan
        if self.current_sort_mode == "piece":
            self.view.table_view.setSortingEnabled(False) # Désactiver le tri par clic
        else:
            self.view.table_view.setSortingEnabled(True)
            self.view.table_view.sortByColumn(-1, Qt.AscendingOrder)
        
        print("DEBUG LOAD: Table operations complete.")