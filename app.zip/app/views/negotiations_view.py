from PySide6.QtWidgets import QWidget, QVBoxLayout, QTableView, QLabel, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt

class NegotiationsView(QWidget):
    """
    View to display negotiation KPIs, showing savings made on purchases.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.layout = QVBoxLayout(self)
        
        # Titre
        title_label = QLabel(self.tr("<h2>Negotiation Savings Report</h2>"))
        title_label.setAlignment(Qt.AlignCenter)
        self.layout.addWidget(title_label)

        # Layout for controls (like sort button)
        controls_layout = QHBoxLayout()
        self.toggle_sort_button = QPushButton(self.tr("Sort by Item Reference")) # Default text
        self.toggle_sort_button.setObjectName("toggleSortButton")
        # === TESTS DE VISIBILITÉ ===
        self.toggle_sort_button.setMinimumHeight(30) # Lui donner une hauteur minimale
        self.toggle_sort_button.setVisible(True) # Forcer la visibilité (même si c'est par défaut)
        print(f"DEBUG VIEW: Toggle button created. Initial isVisible: {self.toggle_sort_button.isVisible()}")
        # ===========================

        controls_layout.addWidget(self.toggle_sort_button)
        controls_layout.addStretch() # Push button to the left, or add other controls later
        self.layout.addLayout(controls_layout)
        
        # Table View pour afficher les détails
        self.table_view = QTableView()
        self.table_view.setSortingEnabled(True)
        self.table_view.setAlternatingRowColors(True)
        self.layout.addWidget(self.table_view)
        
        # Zone pour afficher les totaux
        summary_layout = QHBoxLayout()
        summary_layout.addStretch() # Pour pousser les labels à droite
        
        self.total_savings_label_title = QLabel(self.tr("<b>Total Savings Achieved:</b>"))
        self.total_savings_value_label = QLabel(self.tr("0.00 EUR")) # Valeur par défaut
        self.total_savings_value_label.setStyleSheet("font-weight: bold; color: green;")

        summary_layout.addWidget(self.total_savings_label_title)
        summary_layout.addWidget(self.total_savings_value_label)
        self.layout.addLayout(summary_layout)

        # Optionnel : Boutons pour exporter, rafraîchir
        # self.refresh_button = QPushButton(self.tr("Refresh Data"))
        # self.export_button = QPushButton(self.tr("Export to CSV"))
        # button_layout = QHBoxLayout()
        # button_layout.addWidget(self.refresh_button)
        # button_layout.addWidget(self.export_button)
        # self.layout.addLayout(button_layout)